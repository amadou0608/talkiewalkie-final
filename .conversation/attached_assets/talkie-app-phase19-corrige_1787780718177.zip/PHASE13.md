# Talkie Chat — Phase 13

## Nettoyage et préparation

Cette phase applique la décision du cahier des charges : retirer complètement le PTT/WebRTC et préparer la nouvelle messagerie.

### Supprimé
- `PTTButton.tsx` et son test
- `useWebRTCCall.ts`
- `webrtcConfig.ts`
- `webrtc.signaling.ts`
- le mode verrouillage PTT dans les paramètres
- les références d'appel PTT/WebRTC dans l'écran d'accueil et l'écran de conversation

### Conservé
- Authentification JWT/sessions
- Contacts et présence Socket.IO
- PostgreSQL
- Messages vocaux hors ligne existants, réutilisables pour la phase vocale du chat
- Socket.IO et les rooms utilisateur, qui serviront aux messages temps réel

### Base de données
Migration `005_create_messages.sql` ajoutée avec la table `messages` et les champs définis dans le cahier des charges :
`id`, `sender_id`, `receiver_id`, `type`, `content`, `file_url`, `duration_sec`, `status`, `created_at`, `edited_at`, `deleted_at`.

Les types `text`, `voice`, `image`, `video` et les statuts `sent`, `delivered`, `read` sont créés en PostgreSQL.

## Validation

Le projet a été inspecté statiquement après modification. L'environnement d'exécution disponible ici n'a pas permis de terminer `npm install` (installation des dépendances bloquée par le délai), donc un build/test complet avec les dépendances installées doit être effectué dans l'environnement de développement/deploiement du projet.

## Étape suivante

Phase 14 : messages texte en temps réel, réception, historique, statuts envoyé/délivré/lu et indicateur « en train d'écrire… ».
