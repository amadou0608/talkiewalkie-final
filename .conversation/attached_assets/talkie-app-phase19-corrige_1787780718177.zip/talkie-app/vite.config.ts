import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

// Config Vite — voir README pour le detail des variables d'environnement.
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      // Phase 10 (section 15) : strategie injectManifest plutot que
      // generateSW. On ecrit le service worker a la main (src/sw.ts) pour
      // qu'il gere a la fois le cache/hors-ligne ET les notifications push
      // (anciennement public/push-sw.js) dans UN SEUL fichier — deux
      // service workers enregistres separement sur la meme scope ('/')
      // s'ecraseraient l'un l'autre. vite-plugin-pwa se charge seulement
      // d'y injecter la liste des fichiers a precacher.
      strategies: 'injectManifest',
      srcDir: 'src',
      filename: 'sw.ts',
      // 'prompt' et non 'autoUpdate' : un rechargement silencieux en
      // pleine communication vocale WebRTC couperait l'appel en cours.
      // L'utilisateur choisit le moment via le bandeau UpdateToast.
      registerType: 'prompt',
      injectManifest: {
        globPatterns: ['**/*.{js,css,html,svg,png,ico,woff2}'],
      },
      includeAssets: [
        'favicon.ico',
        'apple-touch-icon.png',
        'icons/icon-192.png',
        'icons/icon-512.png',
        'icons/icon-maskable.png',
      ],
      manifest: false, // on fournit public/manifest.webmanifest nous-memes
      devOptions: {
        enabled: false, // SW actif uniquement en build de production
      },
    }),
  ],
  resolve: {
    alias: { '@': '/src' },
  },
  server: {
    host: true,
    port: 5173,
  },
})
