# Talkie Chat — Phase 14

## Messages texte en temps réel

Cette phase ajoute le premier vrai module de messagerie de Talkie Chat.

### Backend
- `GET /messages?with=<userId>&limit=100` : historique d'une conversation entre contacts acceptés.
- `POST /messages` : création d'un message texte (1 à 4000 caractères).
- `POST /messages/:messageId/delivered` : passage du message à `delivered` lorsque le destinataire l'a reçu.
- Socket.IO : événements `message:new` et `message:status`.
- Le statut initial est `delivered` si le destinataire possède déjà une connexion Socket.IO active, sinon `sent`.
- Les conversations ne sont accessibles qu'entre contacts acceptés.

### Frontend
- Remplacement de l'écran PTT par un fil de conversation réel.
- Envoi de texte avec bouton et touche Entrée.
- Historique, bulles, horodatage.
- Une coche pour `sent`, deux coches pour `delivered`.
- Réception temps réel sans rechargement de page.

### Hors périmètre
La modification/suppression, le statut `read`, l'indicateur « en train d'écrire », les médias photo/vidéo et les vocaux restent dans les phases prévues par le cahier des charges.
